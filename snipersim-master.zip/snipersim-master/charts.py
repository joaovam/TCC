#!/usr/bin/python
import matplotlib.pyplot as plt
import numpy as np
import os
import sys

_type = str(sys.argv[1]) # Expected: ipc l1cache l2cache

#b_parsec = ['blackscholes','dedup','freqmine','streamcluster','x264']
#b_parsec = ['bodytrack','canneal','facesim','ferret','fluidanimate','raytrace','swaptions','vips']

b_splash = ['fft','lu.cont','lu.ncont','barnes','cholesky','radix','raytrace','ocean.cont','ocean.ncont','radiosity']
b_splash = ['fft','ocean.cont','lu.cont']

policies = ['bitrp_0.25','bitrp_0.5','bitrp_0.75','lru','random']
labels   = ['BitRP 25%' ,'BitRP 50%','BitRP 75%' ,'LRU','Random']

policies = ['lru','lru_dmrus','mru','mru_dmrus','nru','nru_dmrus','random','random_dmrus'] #['lru','lru_mru','lru_dmrus']#,'lru_s2m','lru_m2s','lru_bits_0.75']#'bitrp','lru','random']
labels   = ['LRU','LRU-MRUS','MRU','MRU-MRUS','NRU','NRU-MRUS','RANDOM','RANDOM-DMRUS']

def autolabel(rects_a, rects_ref):
  for i, rect in enumerate(rects_a):
    height = float(rect.get_height())
    ref = float(rects_ref[i])
    ref = (ref-height)/ref
    color = "red" if ref<0 else "blue" if ref>0 else "black"
    
    text = ''
    if _type=='ipc':
      text = ('%.2f (%.2f %%)' % (height,ref*100))
    elif (_type=='cycles' or _type=='instructions'):
      text = ('%d (%.2f %%)' % (height/1000000,ref*100))
    else:
      text = ('%.2f (%.2f %%)' % (height*100, ref*100))

    plt.text(rect.get_x() + rect.get_width()*0.5,
            height, text,
            ha='center', va='bottom', fontsize="9", rotation=45, color=color)

results = {}
#for i in range(1,nIter+1):
for policy in policies:
  data = []
  for app in b_splash:
    sThreshold = ""
    fPath = "%s/saida_small/l2p_%s/%s/sim.out" % (os.getcwd(),policy,app)#,i)

    with open(fPath, 'r') as infile:
      lines = [line for line in infile]
    try:
      if _type=='ipc':
        instructions = sum([int(i) for i in [x.strip() for x in lines[1:2][0].split('|')][1:33]])
        cycles = [x.strip() for x in lines[2:3][0].split('|')][1]
        data.append(float(instructions)/float(cycles));
      if _type=='instructions':
        instructions = sum([int(i) for i in [x.strip() for x in lines[1:2][0].split('|')][1:33]])
        data.append(float(instructions));
      if _type=='cycles':
        cycles = float([x.strip() for x in lines[2:3][0].split('|')][1])
        data.append(float(cycles));
      elif _type=='l1cache':
        accesses = sum([float(i) for i in [x.strip() for x in lines[35:36][0].split('|')][1:33]])
        misses = sum([float(i) for i in [x.strip() for x in lines[36:37][0].split('|')][1:33]])
        data.append(misses/accesses);
      elif _type=='l2cache':
        accesses = sum([float(i) for i in [x.strip() for x in lines[40:41][0].split('|')][1:33]])
        misses = sum([float(i) for i in [x.strip() for x in lines[41:42][0].split('|')][1:33]])
        data.append(misses/accesses);
    except Exception as e:
      print("ERRO: %s - %s \n %s" % (policy, app, e))
  results[policy] = data


font = {'family' : 'serif', 'size'   : 14}
plt.rc('font', **font)
plt.figure(figsize=(20,10))

bar_width = 1
bar_pos = np.arange(len(b_splash))
x_ticks = (2*bar_pos) + (bar_pos * len(policies) + (len(policies)/2-0.5))

# make bar plots
rgb = (0, 0, 0)
for i, policy in enumerate(policies):
  rgb = tuple(x+0.1 for x in rgb)
  position = (2*bar_pos) + (bar_pos * len(policies) + i)
  _bar = plt.bar(position, results[policy], bar_width, color=rgb, label=labels[i])
  autolabel(_bar, results['lru'])


plt.xticks(x_ticks, b_splash)
plt.legend(loc='best')
if _type=='l1cache':
  plt.ylim((0, 0.2))
  y_labels = ['{:1.0f}%'.format(x*100) for x in plt.gca().get_yticks()]
  plt.gca().set_yticklabels(y_labels) 
  plt.ylabel('Miss rate (%)')
  plt.savefig('l1cache_chart.pdf', format='pdf')
elif _type=='l2cache':
  plt.ylim((0, 1))
  plt.gca().set_yticklabels(['{:1.0f}%'.format(x*100) for x in plt.gca().get_yticks()]) 
  plt.ylabel('Miss rate (%)')
  plt.savefig('l2cache_chart.pdf', format='pdf')
elif _type=='ipc':
  plt.ylabel('IPC')
  plt.savefig('ipc_chart.pdf', format='pdf')
elif _type=='cycles':
  plt.ylabel('Cycles (Millions)')
  plt.savefig('cycles_chart.pdf', format='pdf')
elif _type=='instructions':
  plt.ylabel('Instructions (Millions)')
  plt.savefig('inst_chart.pdf', format='pdf')
