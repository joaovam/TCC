#!/usr/bin/python

#
# ./benchmarks/CAPBenchmarks/x86/bin/fn.intel --nthreads 8 --class tiny
#
# ../../run-sniper -n8 -c gainestown --roi -- ./$(TARGET) -p8 -m12
#

import os
from math import log

bench = "/home/matheus.souza/sniper/benchmarks/CAPBenchmarks/x86/bin"
sniper = "/home/matheus.souza/sniper"

apps = ['fast','fn','gf','is','km','lu','nb','rt','tsp']
policies = []
for alg in ['plru','srrip','lfu','nru','random','mru','lru']:
	policies.append(alg)
	for strat in ['dmrus','m','e','s']:
		policies.append(f"{alg}_{strat}")

srrip_bits = 0
threshold = '0.5'

for l2priv in [True,False]:
	for assoc in [4,8,16]:
		for app in apps:
			for policy in policies:
				sThreshold = "-g perf_model/bitrp/threshold=%s " % (threshold)
				folder = "%s/cap_output/l2%s_%d_%s/%s" % (sniper,'p' if l2priv else 's',assoc,policy,app)

				if not os.path.exists(folder):
					os.makedirs(folder)

				appcmd = f"{bench}/{app}.intel --nthreads 16 --class standard "
				cmd = ("%s/run-sniper -d %s -n16 -c gainestown --roi " # sniper, folder
					"-g perf_model/l1d_cache/replacement_policy=%s " # policy
					"-g perf_model/l1d_cache/srrip/bits=3 " # 2^3=8
					"-g perf_model/l2_cache/replacement_policy=%s " # policy
					"-g perf_model/l2_cache/shared_cores=%s " # l2priv?1:16
					"-g perf_model/l2_cache/cache_size=%s " # l2_size
					"-g perf_model/l2_cache/associativity=%s " # l2_assoc
					"-g perf_model/l2_cache/srrip/bits=%s " # srrip_bits
					"%s "   # sThreshold
					"-- %s ; "   # appcmd
					) % (sniper,folder,policy, policy,"1" if l2priv else "16", "256" if l2priv else "4096",assoc,str(int(log(assoc,2))), sThreshold,appcmd)
				os.system(cmd)
