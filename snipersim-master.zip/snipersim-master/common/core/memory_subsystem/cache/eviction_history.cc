#include "eviction_history.h"
#include "cache_set.h"
#include "cache_base.h"
#include "log.h"

EvictionHistory::EvictionHistory(UInt32 size, CacheBase::cache_t cache_type):
      m_size(size), m_cache_type(cache_type)
{
   m_block_history = new CacheBlockInfo*[m_size];
   m_lru_bits = new UInt8[m_size];
   m_bad_decision_history = new bool[m_size];
   m_valid_control = new bool[m_size];

   for (UInt32 i = 0; i < m_size; i++)
   {
      m_block_history[i] = CacheBlockInfo::create(m_cache_type);
      m_lru_bits[i] = i;
      m_valid_control[i] = false;
      m_bad_decision_history[i] = false;
   }
}

void
EvictionHistory::printHistory(void)
{
	bool hadSomething = false;
	
	for(UInt32 i = 0; i < m_size; i++)
	{
		if(m_valid_control[i]) {
			UInt8 num_sharers=0;
			printf("%c-%c-%c;",
					m_block_history[i]->getStateChar(),
					m_bad_decision_history[i]?'B':'G',
					m_block_history[i]->hasFewSharers()?'F':'M'
				);
			hadSomething = true;
		}
	}
	if(hadSomething) {
		switch(m_cache_type)
		{
			case CacheBase::PR_L1_CACHE:  printf("== L1  "); break;
			case CacheBase::PR_L2_CACHE:  printf("== L2P "); break;
			case CacheBase::SHARED_L2:    printf("== L2S "); break;
			case CacheBase::SHARED_CACHE: printf("== L3S "); break;
			default: LOG_PRINT_ERROR("Unrecognized Cache type"); break;
		}
		printf("\n");
	}
}

void
EvictionHistory::registerEviction(CacheBlockInfo* cache_block_info)
{
	removeFromHistory(cache_block_info);
	UInt32 index = 0;
	index = getReplacementIndex();
	m_block_history[index] = CacheBlockInfo::create(m_cache_type);
	m_block_history[index]->clone(cache_block_info);
	m_valid_control[index] = true;
}

void
EvictionHistory::removeFromHistory(CacheBlockInfo* cache_block_info)
{
    for(UInt32 i = 0; i < m_size; i++)
	{
		if(m_valid_control[i] && cache_block_info->getTag() == m_block_history[i]->getTag())
		{
			m_block_history[i] = NULL;
			m_valid_control[i] = false;
			m_bad_decision_history[i] = false;
			break;
		}
	} 	
}

void
EvictionHistory::checkBadDecision(IntPtr &tag)
{
	if(tag == ((IntPtr) ~0)) {
		return;
	}
	// A miss occurred when searching for this block
	for(UInt32 i = 0; i < m_size; i++)
	{
		if(m_valid_control[i] && tag == m_block_history[i]->getTag())
		{
			m_bad_decision_history[i] = true;
			updateWeights();
			break;
		}
	}
}

void
EvictionHistory::updateWeights(void)
{
	float total = 0, n_mod = 0, n_exc = 0, n_few = 0;
	for(UInt32 i = 0; i < m_size; i++)
	{
		if(m_valid_control[i] && m_bad_decision_history[i])
		{
			total++;
			if(m_block_history[i]->getCState()==CacheState::MODIFIED)
				n_mod++;
			else if (m_block_history[i]->getCState()==CacheState::EXCLUSIVE)
				n_exc++;

			if(m_block_history[i]->hasFewSharers())
				n_few++;
		}
	}
	m_state_weights[0] = n_mod/total;
	m_state_weights[1] = n_exc/total;
	m_state_weights[2] = 1 - (m_state_weights[0] + m_state_weights[1]);
	m_threshold_weights[0] = n_few/total;
	m_threshold_weights[1] = 1 - m_threshold_weights[0];
}

CacheState::cstate_t
EvictionHistory::currentStateToKeep(void)
{
	if(m_state_weights[0] > m_state_weights[1]) {
		if(m_state_weights[0] > m_state_weights[2]) {
			return CacheState::MODIFIED;
		} else {
			return CacheState::SHARED;
		}
	} else {
		if(m_state_weights[1] > m_state_weights[2]) {
			return CacheState::EXCLUSIVE;
		} else {
			return CacheState::SHARED;
		}
	}
}

bool
EvictionHistory::isCurrentThresholdSuperior(void)
{
	return m_threshold_weights[1] > m_threshold_weights[0];
}

void
EvictionHistory::moveToMRU(UInt8 index)
{
   for (UInt32 i = 0; i < m_size; i++)
   {
      if (m_lru_bits[i] < m_lru_bits[index])
         m_lru_bits[i] ++;
   }
   m_lru_bits[index] = 0;
}

UInt32
EvictionHistory::getReplacementIndex()
{
	for(UInt32 i = 0; i < m_size; i++)
	{
		if(!m_valid_control[i])
		{
			moveToMRU(i);
			return i;
		}
	}

	UInt32 index = 0, max_bits = 0;
	for(UInt32 i = 0; i < m_size; i++)
	{
		if(m_lru_bits[i] > max_bits)
		{
			index = i;
			max_bits = m_lru_bits[i];
		}
	}

	moveToMRU(index);
	return index;
}

EvictionHistory::~EvictionHistory()
{
   for (UInt32 i = 0; i < m_size; i++)
      delete m_block_history[i];
   delete [] m_lru_bits;
   delete [] m_bad_decision_history;
   delete [] m_valid_control;
   delete [] m_block_history;
}
