#ifndef CACHE_SET_LRU_S_H
#define CACHE_SET_LRU_S_H

#include "cache_set.h"

class CacheSetLRUS : public CacheSet
{
   public:
      CacheSetLRUS(CacheBase::cache_t cache_type,
            UInt32 associativity, UInt32 blocksize);
      virtual ~CacheSetLRUS();

      virtual UInt32 getReplacementIndex(CacheCntlr *cntlr);
      void updateReplacementIndex(UInt32 accessed_index);

   protected:
      UInt8* m_lru_bits;
      CacheState::cstate_t m_mru_state;
      void moveToMRU(UInt32 accessed_index);
};

#endif /* CACHE_SET_LRU_S_H */
