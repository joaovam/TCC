#ifndef CACHE_SET_LRU_RLBS_H
#define CACHE_SET_LRU_RLBS_H

#include "cache_set.h"

class CacheSetLRURLBS : public CacheSet
{
   public:
      CacheSetLRURLBS(CacheBase::cache_t cache_type,
            UInt32 associativity, UInt32 blocksize);
      virtual ~CacheSetLRURLBS();

      virtual UInt32 getReplacementIndex(CacheCntlr *cntlr);
      void updateReplacementIndex(UInt32 accessed_index);

   protected:
      UInt8* m_lru_bits;
      void moveToMRU(UInt32 accessed_index);
};

#endif /* CACHE_SET_LRU_RLBS_H */
