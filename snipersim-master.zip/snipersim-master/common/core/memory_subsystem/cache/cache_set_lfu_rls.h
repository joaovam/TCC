#ifndef CACHE_SET_LFU_RLS_H
#define CACHE_SET_LFU_RLS_H

#include "cache_set.h"

class CacheSetLFURLS : public CacheSet
{
   public:
      CacheSetLFURLS(CacheBase::cache_t cache_type,
            UInt32 associativity, UInt32 blocksize);
      virtual ~CacheSetLFURLS();

      virtual UInt32 getReplacementIndex(CacheCntlr *cntlr);
      void updateReplacementIndex(UInt32 accessed_index);

   protected:
      UInt32* m_freq;
};

#endif /* CACHE_SET_LFU_RLS_H */
