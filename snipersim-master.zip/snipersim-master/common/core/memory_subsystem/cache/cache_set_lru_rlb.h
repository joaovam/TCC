#ifndef CACHE_SET_LRU_RLB_H
#define CACHE_SET_LRU_RLB_H

#include "cache_set.h"

class CacheSetLRURLB : public CacheSet
{
   public:
      CacheSetLRURLB(CacheBase::cache_t cache_type,
            UInt32 associativity, UInt32 blocksize);
      virtual ~CacheSetLRURLB();

      virtual UInt32 getReplacementIndex(CacheCntlr *cntlr);
      void updateReplacementIndex(UInt32 accessed_index);

   protected:
      UInt8* m_lru_bits;
      void moveToMRU(UInt32 accessed_index);
};

#endif /* CACHE_SET_LRU_RLB_H */
