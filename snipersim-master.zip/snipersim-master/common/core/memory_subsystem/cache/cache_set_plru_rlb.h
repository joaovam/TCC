#ifndef CACHE_SET_PLRU_RLB_H
#define CACHE_SET_PLRU_RLB_H

#include "cache_set.h"

class CacheSetPLRURLB : public CacheSet
{
   public:
      CacheSetPLRURLB(CacheBase::cache_t cache_type,
            UInt32 associativity, UInt32 blocksize);
      ~CacheSetPLRURLB();

      UInt32 getReplacementIndex(CacheCntlr *cntlr);
      void updateReplacementIndex(UInt32 accessed_index);

   private:
      UInt8 b[16];
};

#endif /* CACHE_SET_PLRU_RLB_H */
