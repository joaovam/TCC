#ifndef CACHE_SET_NRU_DMRUS_H
#define CACHE_SET_NRU_DMRUS_H

#include "cache_set.h"

class CacheSetNRUDMRUS : public CacheSet
{
   public:
      CacheSetNRUDMRUS(CacheBase::cache_t cache_type,
            UInt32 associativity, UInt32 blocksize);
      ~CacheSetNRUDMRUS();

      UInt32 getReplacementIndex(CacheCntlr *cntlr);
      void updateReplacementIndex(UInt32 accessed_index);
      void updateMRUState(UInt32 accessed_index);

   private:
      UInt8* m_lru_bits;
      UInt8  m_num_bits_set;
      UInt8  m_replacement_pointer;
      CacheState::cstate_t m_mru_state;
};

#endif /* CACHE_SET_NRU_DMRUS_H */
