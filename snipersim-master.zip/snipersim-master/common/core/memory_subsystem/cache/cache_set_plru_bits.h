#ifndef CACHE_SET_PLRU_BITS_H
#define CACHE_SET_PLRU_BITS_H

#include "cache_set.h"

class CacheSetPLRUBits : public CacheSet
{
   public:
      CacheSetPLRUBits(CacheBase::cache_t cache_type,
            UInt32 associativity, UInt32 blocksize);
      ~CacheSetPLRUBits();

      UInt32 getReplacementIndex(CacheCntlr *cntlr);
      void updateReplacementIndex(UInt32 accessed_index);

   private:
      UInt8 b[16];
};

#endif /* CACHE_SET_PLRU_BITS_H */
