#ifndef CACHE_SET_NRU_E_H
#define CACHE_SET_NRU_E_H

#include "cache_set.h"

class CacheSetNRUE : public CacheSet
{
   public:
      CacheSetNRUE(CacheBase::cache_t cache_type,
            UInt32 associativity, UInt32 blocksize);
      ~CacheSetNRUE();

      UInt32 getReplacementIndex(CacheCntlr *cntlr);
      void updateReplacementIndex(UInt32 accessed_index);

   private:
      UInt8* m_lru_bits;
      UInt8  m_num_bits_set;
      UInt8  m_replacement_pointer;
      CacheState::cstate_t m_mru_state;
};

#endif /* CACHE_SET_NRU_E_H */
