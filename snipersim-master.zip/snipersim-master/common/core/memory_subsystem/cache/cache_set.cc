#include "cache_set.h"

#include "cache_set_lru.h"
#include "cache_set_lru_S.h"
#include "cache_set_lru_M.h"
#include "cache_set_lru_E.h"
#include "cache_set_lru_dmrus.h"
#include "cache_set_lru_bits.h"
#include "cache_set_lru_rls.h"
#include "cache_set_lru_rlb.h"
#include "cache_set_lru_rlbs.h"

#include "cache_set_mru.h"
#include "cache_set_mru_S.h"
#include "cache_set_mru_M.h"
#include "cache_set_mru_E.h"
#include "cache_set_mru_dmrus.h"
#include "cache_set_mru_bits.h"
#include "cache_set_mru_rls.h"
#include "cache_set_mru_rlb.h"
#include "cache_set_mru_rlbs.h"

#include "cache_set_nru.h"
#include "cache_set_nru_S.h"
#include "cache_set_nru_M.h"
#include "cache_set_nru_E.h"
#include "cache_set_nru_dmrus.h"
#include "cache_set_nru_bits.h"
#include "cache_set_nru_rls.h"
#include "cache_set_nru_rlb.h"
#include "cache_set_nru_rlbs.h"

#include "cache_set_plru.h"
#include "cache_set_plru_S.h"
#include "cache_set_plru_M.h"
#include "cache_set_plru_E.h"
#include "cache_set_plru_dmrus.h"
#include "cache_set_plru_bits.h"
#include "cache_set_plru_rls.h"
#include "cache_set_plru_rlb.h"
#include "cache_set_plru_rlbs.h"

#include "cache_set_random.h"
#include "cache_set_random_S.h"
#include "cache_set_random_M.h"
#include "cache_set_random_E.h"
#include "cache_set_random_dmrus.h"
#include "cache_set_random_bits.h"

#include "cache_set_srrip.h"
#include "cache_set_srrip_S.h"
#include "cache_set_srrip_M.h"
#include "cache_set_srrip_E.h"
#include "cache_set_srrip_dmrus.h"
#include "cache_set_srrip_bits.h"
#include "cache_set_srrip_rls.h"
#include "cache_set_srrip_rlb.h"
#include "cache_set_srrip_rlbs.h"

#include "cache_set_lfu.h"
#include "cache_set_lfu_S.h"
#include "cache_set_lfu_M.h"
#include "cache_set_lfu_E.h"
#include "cache_set_lfu_dmrus.h"
#include "cache_set_lfu_bits.h"
#include "cache_set_lfu_rls.h"
#include "cache_set_lfu_rlb.h"
#include "cache_set_lfu_rlbs.h"

#include "cache_base.h"
#include "log.h"
#include "simulator.h"
#include "config.h"
#include "config.hpp"

CacheSet::CacheSet(CacheBase::cache_t cache_type,
      UInt32 associativity, UInt32 blocksize):
      m_associativity(associativity), m_blocksize(blocksize)
{
   m_cache_block_info_array = new CacheBlockInfo*[m_associativity];   
   m_eviction_history = new EvictionHistory(m_associativity, cache_type);
   
   for (UInt32 i = 0; i < m_associativity; i++)
   {
      m_cache_block_info_array[i] = CacheBlockInfo::create(cache_type);
   }

   if (Sim()->getFaultinjectionManager())
   {
      m_blocks = new char[m_associativity * m_blocksize];
      memset(m_blocks, 0x00, m_associativity * m_blocksize);
   } else {
      m_blocks = NULL;
   }
}

CacheSet::~CacheSet()
{
   for (UInt32 i = 0; i < m_associativity; i++)
      delete m_cache_block_info_array[i];
   delete [] m_cache_block_info_array;
   delete [] m_blocks;
}

void
CacheSet::read_line(UInt32 line_index, UInt32 offset, Byte *out_buff, UInt32 bytes, bool update_replacement)
{
   assert(offset + bytes <= m_blocksize);
   //assert((out_buff == NULL) == (bytes == 0));

   if (out_buff != NULL && m_blocks != NULL)
      memcpy((void*) out_buff, &m_blocks[line_index * m_blocksize + offset], bytes);

   if (update_replacement)
      updateReplacementIndex(line_index);
}

void
CacheSet::write_line(UInt32 line_index, UInt32 offset, Byte *in_buff, UInt32 bytes, bool update_replacement)
{
   assert(offset + bytes <= m_blocksize);
   //assert((in_buff == NULL) == (bytes == 0));

   if (in_buff != NULL && m_blocks != NULL)
      memcpy(&m_blocks[line_index * m_blocksize + offset], (void*) in_buff, bytes);

   if (update_replacement)
      updateReplacementIndex(line_index);
}

CacheBlockInfo*
CacheSet::find(IntPtr tag, UInt32* line_index)
{
   for (SInt32 index = m_associativity-1; index >= 0; index--)
   {
      if (m_cache_block_info_array[index]->getTag() == tag)
      {
         if (line_index != NULL)
            *line_index = index;
         return (m_cache_block_info_array[index]);
      }
   }
   // TAG not found in cache set
   m_eviction_history->checkBadDecision(tag);
   return NULL;
}

bool
CacheSet::invalidate(IntPtr& tag)
{
   for (SInt32 index = m_associativity-1; index >= 0; index--)
   {
      if (m_cache_block_info_array[index]->getTag() == tag)
      {
         m_cache_block_info_array[index]->invalidate();
         return true;
      }
   }
   return false;
}

void
CacheSet::insert(CacheBlockInfo* cache_block_info, Byte* fill_buff, bool* eviction, CacheBlockInfo* evict_block_info, Byte* evict_buff, CacheCntlr *cntlr)
{
   // This replacement strategy does not take into account the fact that
   // cache blocks can be voluntarily flushed or invalidated due to another write request
   const UInt32 index = getReplacementIndex(cntlr);
   assert(index < m_associativity);
   assert(eviction != NULL);

   if (m_cache_block_info_array[index]->isValid())
   {
      *eviction = true;
      // FIXME: This is a hack. I dont know if this is the best way to do
      evict_block_info->clone(m_cache_block_info_array[index]);
      
      m_eviction_history->registerEviction(evict_block_info);
      
      if (evict_buff != NULL && m_blocks != NULL)
         memcpy((void*) evict_buff, &m_blocks[index * m_blocksize], m_blocksize);
   }
   else
   {
      *eviction = false;
   }

   // FIXME: This is a hack. I dont know if this is the best way to do
   m_cache_block_info_array[index]->clone(cache_block_info);

   m_eviction_history->removeFromHistory(cache_block_info);

   if (fill_buff != NULL && m_blocks != NULL)
      memcpy(&m_blocks[index * m_blocksize], (void*) fill_buff, m_blocksize);
   //m_eviction_history->printHistory();
}

char*
CacheSet::getDataPtr(UInt32 line_index, UInt32 offset)
{
   return &m_blocks[line_index * m_blocksize + offset];
}

CacheSet*
CacheSet::createCacheSet(String cfgname, core_id_t core_id,
      String replacement_policy,
      CacheBase::cache_t cache_type,
      UInt32 associativity, UInt32 blocksize)
{
   CacheBase::ReplacementPolicy policy = parsePolicyType(replacement_policy);
   switch(policy)
   {
      case CacheBase::LRU: return new CacheSetLRU(cache_type, associativity, blocksize);
      case CacheBase::LRU_M: return new CacheSetLRUM(cache_type, associativity, blocksize);
      case CacheBase::LRU_S: return new CacheSetLRUS(cache_type, associativity, blocksize);
      case CacheBase::LRU_E: return new CacheSetLRUE(cache_type, associativity, blocksize);
      case CacheBase::LRU_DMRUS: return new CacheSetLRUDMRUS(cache_type, associativity, blocksize);
      case CacheBase::LRU_BITS: return new CacheSetLRUBits(cache_type, associativity, blocksize);

      case CacheBase::LRU_RLS: return new CacheSetLRURLS(cache_type, associativity, blocksize);
      case CacheBase::LRU_RLB: return new CacheSetLRURLB(cache_type, associativity, blocksize);
      case CacheBase::LRU_RLBS: return new CacheSetLRURLBS(cache_type, associativity, blocksize);

      case CacheBase::LFU: return new CacheSetLFU(cache_type, associativity, blocksize);
      case CacheBase::LFU_M: return new CacheSetLFUM(cache_type, associativity, blocksize);
      case CacheBase::LFU_S: return new CacheSetLFUS(cache_type, associativity, blocksize);
      case CacheBase::LFU_E: return new CacheSetLFUE(cache_type, associativity, blocksize);
      case CacheBase::LFU_DMRUS: return new CacheSetLFUDMRUS(cache_type, associativity, blocksize);
      case CacheBase::LFU_BITS: return new CacheSetLFUBits(cache_type, associativity, blocksize);

      case CacheBase::LFU_RLS: return new CacheSetLFURLS(cache_type, associativity, blocksize);
      case CacheBase::LFU_RLB: return new CacheSetLFURLB(cache_type, associativity, blocksize);
      case CacheBase::LFU_RLBS: return new CacheSetLFURLBS(cache_type, associativity, blocksize);

      case CacheBase::NRU: return new CacheSetNRU(cache_type, associativity, blocksize);
      case CacheBase::NRU_M: return new CacheSetNRUM(cache_type, associativity, blocksize);
      case CacheBase::NRU_S: return new CacheSetNRUS(cache_type, associativity, blocksize);
      case CacheBase::NRU_E: return new CacheSetNRUE(cache_type, associativity, blocksize);
      case CacheBase::NRU_DMRUS: return new CacheSetNRUDMRUS(cache_type, associativity, blocksize);
      case CacheBase::NRU_BITS: return new CacheSetNRUBits(cache_type, associativity, blocksize);
      
      case CacheBase::NRU_RLS: return new CacheSetNRURLS(cache_type, associativity, blocksize);
      case CacheBase::NRU_RLB: return new CacheSetNRURLB(cache_type, associativity, blocksize);
      case CacheBase::NRU_RLBS: return new CacheSetNRURLBS(cache_type, associativity, blocksize);

      case CacheBase::MRU: return new CacheSetMRU(cache_type, associativity, blocksize);
      case CacheBase::MRU_M: return new CacheSetMRUM(cache_type, associativity, blocksize);
      case CacheBase::MRU_S: return new CacheSetMRUS(cache_type, associativity, blocksize);
      case CacheBase::MRU_E: return new CacheSetMRUE(cache_type, associativity, blocksize);
      case CacheBase::MRU_DMRUS: return new CacheSetMRUDMRUS(cache_type, associativity, blocksize);
      case CacheBase::MRU_BITS: return new CacheSetMRUBits(cache_type, associativity, blocksize);

      case CacheBase::MRU_RLS: return new CacheSetMRURLS(cache_type, associativity, blocksize);
      case CacheBase::MRU_RLB: return new CacheSetMRURLB(cache_type, associativity, blocksize);
      case CacheBase::MRU_RLBS: return new CacheSetMRURLBS(cache_type, associativity, blocksize);

      case CacheBase::PLRU: return new CacheSetPLRU(cache_type, associativity, blocksize);
      case CacheBase::PLRU_M: return new CacheSetPLRUM(cache_type, associativity, blocksize);
      case CacheBase::PLRU_S: return new CacheSetPLRUS(cache_type, associativity, blocksize);
      case CacheBase::PLRU_E: return new CacheSetPLRUE(cache_type, associativity, blocksize);
      case CacheBase::PLRU_DMRUS: return new CacheSetPLRUDMRUS(cache_type, associativity, blocksize);
      case CacheBase::PLRU_BITS: return new CacheSetPLRUBits(cache_type, associativity, blocksize);

      case CacheBase::PLRU_RLS: return new CacheSetPLRURLS(cache_type, associativity, blocksize);
      case CacheBase::PLRU_RLB: return new CacheSetPLRURLB(cache_type, associativity, blocksize);
      case CacheBase::PLRU_RLBS: return new CacheSetPLRURLBS(cache_type, associativity, blocksize);
        
      case CacheBase::SRRIP: return new CacheSetSRRIP(cfgname, core_id, cache_type, associativity, blocksize);
      case CacheBase::SRRIP_M: return new CacheSetSRRIPM(cfgname, core_id, cache_type, associativity, blocksize);
      case CacheBase::SRRIP_S: return new CacheSetSRRIPS(cfgname, core_id, cache_type, associativity, blocksize);
      case CacheBase::SRRIP_E: return new CacheSetSRRIPE(cfgname, core_id, cache_type, associativity, blocksize);
      case CacheBase::SRRIP_DMRUS: return new CacheSetSRRIPDMRUS(cfgname, core_id, cache_type, associativity, blocksize);
      case CacheBase::SRRIP_BITS: return new CacheSetSRRIPBits(cfgname, core_id, cache_type, associativity, blocksize);

      case CacheBase::SRRIP_RLS: return new CacheSetSRRIPRLS(cfgname, core_id, cache_type, associativity, blocksize);
      case CacheBase::SRRIP_RLB: return new CacheSetSRRIPRLB(cfgname, core_id, cache_type, associativity, blocksize);
      case CacheBase::SRRIP_RLBS: return new CacheSetSRRIPRLBS(cfgname, core_id, cache_type, associativity, blocksize);
/*
      case CacheBase::RANDOM: return new CacheSetRandom(cache_type, associativity, blocksize);
      case CacheBase::RANDOM_M: return new CacheSetRandomM(cache_type, associativity, blocksize);
      case CacheBase::RANDOM_S: return new CacheSetRandomS(cache_type, associativity, blocksize);
      case CacheBase::RANDOM_E: return new CacheSetRandomE(cache_type, associativity, blocksize);
      case CacheBase::RANDOM_DMRUS: return new CacheSetRandomDMRUS(cache_type, associativity, blocksize);
      case CacheBase::RANDOM_BITS: return new CacheSetRandomBits(cache_type, associativity, blocksize);
*/
      default:
         LOG_PRINT_ERROR("Unrecognized Cache Replacement Policy: %i",
               policy);
         break;
   }

   return (CacheSet*) NULL;
}

CacheBase::ReplacementPolicy
CacheSet::parsePolicyType(String policy)
{
   if (policy == "lru")       return CacheBase::LRU;
   if (policy == "lru_m")     return CacheBase::LRU_M;
   if (policy == "lru_s")     return CacheBase::LRU_S;
   if (policy == "lru_e")     return CacheBase::LRU_E;
   if (policy == "lru_dmrus") return CacheBase::LRU_DMRUS;
   if (policy == "lru_bits")  return CacheBase::LRU_BITS;
   if (policy == "lru_rls")   return CacheBase::LRU_RLS;
   if (policy == "lru_rlb")   return CacheBase::LRU_RLB;
   if (policy == "lru_rlbs")   return CacheBase::LRU_RLBS;

   if (policy == "nru")       return CacheBase::NRU;
   if (policy == "nru_m")     return CacheBase::NRU_M;
   if (policy == "nru_s")     return CacheBase::NRU_S;
   if (policy == "nru_e")     return CacheBase::NRU_E;
   if (policy == "nru_dmrus") return CacheBase::NRU_DMRUS;
   if (policy == "nru_bits")  return CacheBase::NRU_BITS;
   if (policy == "nru_rls")  return CacheBase::NRU_RLS;
   if (policy == "nru_rlb")  return CacheBase::NRU_RLB;
   if (policy == "nru_rlbs")  return CacheBase::NRU_RLBS;
   
   if (policy == "mru")       return CacheBase::MRU;
   if (policy == "mru_m")     return CacheBase::MRU_M;
   if (policy == "mru_s")     return CacheBase::MRU_S;
   if (policy == "mru_e")     return CacheBase::MRU_E;
   if (policy == "mru_dmrus") return CacheBase::MRU_DMRUS;
   if (policy == "mru_bits")  return CacheBase::MRU_BITS;
   if (policy == "mru_rls")  return CacheBase::MRU_RLS;
   if (policy == "mru_rlb")  return CacheBase::MRU_RLB;
   if (policy == "mru_rlbs")  return CacheBase::MRU_RLBS;

   if (policy == "plru")       return CacheBase::PLRU;
   if (policy == "plru_m")     return CacheBase::PLRU_M;
   if (policy == "plru_s")     return CacheBase::PLRU_S;
   if (policy == "plru_e")     return CacheBase::PLRU_E;
   if (policy == "plru_dmrus") return CacheBase::PLRU_DMRUS;
   if (policy == "plru_bits")  return CacheBase::PLRU_BITS;
   if (policy == "plru_rls")  return CacheBase::PLRU_RLS;
   if (policy == "plru_rlb")  return CacheBase::PLRU_RLB;
   if (policy == "plru_rlbs")  return CacheBase::PLRU_RLBS;

   if (policy == "srrip")       return CacheBase::SRRIP;
   if (policy == "srrip_m")     return CacheBase::SRRIP_M;
   if (policy == "srrip_s")     return CacheBase::SRRIP_S;
   if (policy == "srrip_e")     return CacheBase::SRRIP_E;
   if (policy == "srrip_dmrus") return CacheBase::SRRIP_DMRUS;
   if (policy == "srrip_bits")  return CacheBase::SRRIP_BITS;
   if (policy == "srrip_rls")  return CacheBase::SRRIP_RLS;
   if (policy == "srrip_rlb")  return CacheBase::SRRIP_RLB;
   if (policy == "srrip_rlbs")  return CacheBase::SRRIP_RLBS;

   if (policy == "lfu")       return CacheBase::LFU;
   if (policy == "lfu_m")     return CacheBase::LFU_M;
   if (policy == "lfu_s")     return CacheBase::LFU_S;
   if (policy == "lfu_e")     return CacheBase::LFU_E;
   if (policy == "lfu_dmrus") return CacheBase::LFU_DMRUS;
   if (policy == "lfu_bits")  return CacheBase::LFU_BITS;
   if (policy == "lfu_rls")  return CacheBase::LFU_RLS;
   if (policy == "lfu_rlb")  return CacheBase::LFU_RLB;
   if (policy == "lfu_rlbs")  return CacheBase::LFU_RLBS;

   LOG_PRINT_ERROR("Unknown replacement policy %s", policy.c_str());
}

bool CacheSet::isValidReplacement(UInt32 index)
{
   if (m_cache_block_info_array[index]->getCState() == CacheState::SHARED_UPGRADING)
   {
      return false;
   }
   else
   {
      return true;
   }
}
