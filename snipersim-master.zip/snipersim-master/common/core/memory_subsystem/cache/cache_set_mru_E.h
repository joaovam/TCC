#ifndef CACHE_SET_MRU_E_H
#define CACHE_SET_MRU_E_H

#include "cache_set.h"

class CacheSetMRUE : public CacheSet
{
   public:
      CacheSetMRUE(CacheBase::cache_t cache_type,
            UInt32 associativity, UInt32 blocksize);
      ~CacheSetMRUE();

      UInt32 getReplacementIndex(CacheCntlr *cntlr);
      void updateReplacementIndex(UInt32 accessed_index);

   private:
      UInt8* m_lru_bits;
      CacheState::cstate_t m_mru_state;
};

#endif /* CACHE_SET_MRU_E_H */
