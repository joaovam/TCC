#ifndef CACHE_SET_RANDOM_BITS_H
#define CACHE_SET_RANDOM_BITS_H

#include "cache_set.h"

class CacheSetRandomBits : public CacheSet
{
   public:
      CacheSetRandomBits(CacheBase::cache_t cache_type,
            UInt32 associativity, UInt32 blocksize);
      ~CacheSetRandomBits();

      UInt32 getReplacementIndex(CacheCntlr *cntlr);
      void updateReplacementIndex(UInt32 accessed_index);

   private:
      Random m_rand;
};

#endif /* CACHE_SET_RANDOM_BITS_H */
