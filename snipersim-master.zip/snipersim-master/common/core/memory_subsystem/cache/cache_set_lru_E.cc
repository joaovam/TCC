#include "cache_set_lru_E.h"
#include "log.h"
#include "stats.h"

CacheSetLRUE::CacheSetLRUE(
      CacheBase::cache_t cache_type,
      UInt32 associativity, UInt32 blocksize)
   : CacheSet(cache_type, associativity, blocksize)
{
   m_lru_bits = new UInt8[m_associativity];
   for (UInt32 i = 0; i < m_associativity; i++)
      m_lru_bits[i] = i;
   m_mru_state = CacheState::EXCLUSIVE;
}

CacheSetLRUE::~CacheSetLRUE()
{
   delete [] m_lru_bits;
}

UInt32
CacheSetLRUE::getReplacementIndex(CacheCntlr *cntlr)
{
   for (UInt32 i = 0; i < m_associativity; i++)
   {
      if (!m_cache_block_info_array[i]->isValid())
      {
         moveToMRU(i);
         return i;
      }
   }

   UInt32 index = 0;
   UInt32 index2 = 0;
   UInt8 max_bits = 0;
   UInt8 max_bits_2 = 0;
   for (UInt32 i = 0; i < m_associativity; i++)
   {
      if(!isValidReplacement(i))
         continue;

      if (m_lru_bits[i] > max_bits)
      {
         index2 = index;
         index = i;

         max_bits_2 = max_bits;
         max_bits = m_lru_bits[i];
      }
      else if (m_lru_bits[i] > max_bits_2 && m_lru_bits[i] != max_bits) 
      {
         index2 = i;
         max_bits_2 = m_lru_bits[i]; 
      }
   }

   LOG_ASSERT_ERROR(index < m_associativity, "Error Finding LRU bits");
   LOG_ASSERT_ERROR(index2 < m_associativity, "Error Finding 2ndLRU bits");

   if(m_cache_block_info_array[index]->getCState() == m_mru_state) {
      moveToMRU(index2);
      return index2;
   } else {
      moveToMRU(index);
      return index;
   }      

   LOG_PRINT_ERROR("Should not reach here");
}

void
CacheSetLRUE::updateReplacementIndex(UInt32 accessed_index)
{
   moveToMRU(accessed_index);
}

void
CacheSetLRUE::moveToMRU(UInt32 accessed_index)
{
   for (UInt32 i = 0; i < m_associativity; i++)
   {
      if (m_lru_bits[i] < m_lru_bits[accessed_index])
         m_lru_bits[i] ++;
   }
   m_lru_bits[accessed_index] = 0;
}
