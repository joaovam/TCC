#ifndef CACHE_SET_PLRU_S_H
#define CACHE_SET_PLRU_S_H

#include "cache_set.h"

class CacheSetPLRUS : public CacheSet
{
   public:
      CacheSetPLRUS(CacheBase::cache_t cache_type,
            UInt32 associativity, UInt32 blocksize);
      ~CacheSetPLRUS();

      UInt32 getReplacementIndex(CacheCntlr *cntlr);
      void updateReplacementIndex(UInt32 accessed_index);

   private:
      UInt8 b[16];
      CacheState::cstate_t m_mru_state;
};

#endif /* CACHE_SET_PLRU_S_H */
