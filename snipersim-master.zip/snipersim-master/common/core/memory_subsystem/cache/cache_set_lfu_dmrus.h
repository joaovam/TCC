#ifndef CACHE_SET_LFU_DMRUS_H
#define CACHE_SET_LFU_DMRUS_H

#include "cache_set.h"

class CacheSetLFUDMRUS : public CacheSet
{
   public:
      CacheSetLFUDMRUS(CacheBase::cache_t cache_type,
            UInt32 associativity, UInt32 blocksize);
      virtual ~CacheSetLFUDMRUS();

      virtual UInt32 getReplacementIndex(CacheCntlr *cntlr);
      void updateReplacementIndex(UInt32 accessed_index);

   protected:
      UInt32* m_freq;
      CacheState::cstate_t m_mru_state;
      void updateMRUState(UInt32 accessed_index);
};

#endif /* CACHE_SET_LFU_DMRUS_H */
