#include "cache_set_bitrp.h"
#include "log.h"

#include <time.h>

CacheSetBitRP::CacheSetBitRP(
      CacheBase::cache_t cache_type,
      UInt32 associativity, UInt32 blocksize) :
   CacheSet(cache_type, associativity, blocksize)
{
    m_rand.seed(time(NULL));
    m_least_shared_indexes = new UInt32[associativity];
}

CacheSetBitRP::~CacheSetBitRP()
{
}

UInt32
CacheSetBitRP::getReplacementIndex(CacheCntlr *cntlr)
{

    for (UInt32 i = 0; i < m_associativity; i++)
    {
        if (!m_cache_block_info_array[i]->isValid())
           return i;
    }

    UInt32 index = (m_rand.next() % m_associativity);
    SharedL2CacheBlockInfo* shared_block = (SharedL2CacheBlockInfo*) m_cache_block_info_array;
    while(!shared_block[index].hasFewSharers()) {
        index = (m_rand.next() % m_associativity);
    } 
    return (isValidReplacement(index)) ? index : getReplacementIndex(cntlr);
}

void
CacheSetBitRP::updateReplacementIndex(UInt32 accessed_index)
{
}
