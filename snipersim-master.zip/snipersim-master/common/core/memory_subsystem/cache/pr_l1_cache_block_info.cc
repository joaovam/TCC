#include "pr_l1_cache_block_info.h"
#include "log.h"

void
PrL1CacheBlockInfo::setCount(UInt8 count) {
   UInt8 threshold = (16 * m_threshold);
   m_has_few_sharers = (count <= threshold) ? 1 : 0;
}
