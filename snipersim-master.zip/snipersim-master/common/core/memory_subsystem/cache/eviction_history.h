#ifndef EVICTION_HISTORY_H
#define EVICTION_HISTORY_H

#include "fixed_types.h"
#include "cache_block_info.h"
#include "random.h"
#include "cache_base.h"
#include "log.h"

class EvictionHistory
{
   protected:
      CacheBlockInfo** m_block_history;
      bool* m_bad_decision_history;
      bool* m_valid_control;
      UInt32 m_size;
      CacheBase::cache_t m_cache_type;
      UInt8* m_lru_bits;
      float m_state_weights[3]; /* 0-M, 1-E, 2-S */
      float m_threshold_weights[2]; /* 0-INF, 1-SUP */
      
      void moveToMRU(UInt8 index);
      UInt32 getReplacementIndex();
      void updateWeights(void);

   public:
      EvictionHistory(UInt32 size, CacheBase::cache_t cache_type);
      virtual ~EvictionHistory();

      void registerEviction(CacheBlockInfo* cache_block_info);
      void removeFromHistory(CacheBlockInfo* cache_block_info);
      void checkBadDecision(IntPtr &tag);
      CacheState::cstate_t currentStateToKeep(void);
      bool isCurrentThresholdSuperior(void);
      void printHistory(void);
      //void checkBadDecision(CacheBlockInfo* cache_block_info);
};

#endif /* EVICTION_HISTORY_H */
