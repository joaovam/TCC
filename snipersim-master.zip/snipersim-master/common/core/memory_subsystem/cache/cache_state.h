#ifndef CACHE_STATE_H
#define CACHE_STATE_H

#include <cassert>

#include "fixed_types.h"

class CacheState
{
   public:
      enum cstate_t
      {
         CSTATE_FIRST = 0,
         INVALID = CSTATE_FIRST, /* 0 */
         SHARED,                 /* 1 */
         SHARED_UPGRADING,       /* 2 */
         EXCLUSIVE,              /* 3 */
         OWNED,                  /* 4 */
         MODIFIED,               /* 5 */
         NUM_CSTATE_STATES,      /* 6 */
         /* Below are special states, used only for reporting */
         INVALID_COLD = NUM_CSTATE_STATES,/* 6 */
         INVALID_EVICT,                   /* 7 */
         INVALID_COHERENCY,               /* 8 */
         NUM_CSTATE_SPECIAL_STATES        /* 9 */
      };

      CacheState(cstate_t state = INVALID) : cstate(state) {}
      ~CacheState() {}

      bool readable()
      {
         return (cstate == MODIFIED) || (cstate == OWNED) || (cstate == SHARED) || (cstate == EXCLUSIVE);
      }

      bool writable()
      {
         return (cstate == MODIFIED);
      }

      static bool isModified(cstate_t state)
      {
         return (state == MODIFIED);
      }

      static bool isShared(cstate_t state)
      {
         return (state == SHARED);
      }

      static bool isInvalid(cstate_t state)
      {
         return (state == INVALID);
      }

      static bool isOwned(cstate_t state)
      {
         return (state == OWNED);
      }

      static bool isExclusive(cstate_t state)
      {
         return (state == EXCLUSIVE);
      }

   private:
      cstate_t cstate;

};

#endif /* CACHE_STATE_H */
