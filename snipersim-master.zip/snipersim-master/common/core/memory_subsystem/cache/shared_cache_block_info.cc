#include "shared_cache_block_info.h"
#include "log.h"

PrevCacheIndex
SharedCacheBlockInfo::getCachedLoc()
{
   LOG_ASSERT_ERROR(m_cached_locs.count() == 1, "m_cached_locs.count() == %u", m_cached_locs.count());

   for(PrevCacheIndex idx = 0; idx < m_cached_locs.size(); ++idx)
      if (m_cached_locs.test(idx))
         return idx;
   assert(false);
}

void
SharedCacheBlockInfo::setCachedLoc(PrevCacheIndex idx)
{
   m_cached_locs.set(idx);
   updateSharersFlag();
}

void
SharedCacheBlockInfo::clearCachedLoc(PrevCacheIndex idx)
{
   m_cached_locs.reset(idx);
   updateSharersFlag();
}

void
SharedCacheBlockInfo::updateSharersFlag() {
   UInt8 threshold = (16 * m_threshold);
   UInt8 count = countSet();
   m_has_few_sharers = (count <= threshold) ? 1 : 0;
}

UInt8
SharedCacheBlockInfo::countSet() {
   size_t count=0;
   for(size_t i=0; i<m_cached_locs.size(); i++) {
      if(m_cached_locs.test(i)) {
         count++;
      }
   }
   return count;
}

void
SharedCacheBlockInfo::invalidate()
{
   m_cached_locs.reset();
   m_has_few_sharers = 1;
   CacheBlockInfo::invalidate();
}

void
SharedCacheBlockInfo::clone(CacheBlockInfo* cache_block_info)
{
   m_cached_locs = ((SharedCacheBlockInfo*) cache_block_info)->getCachedLocs();
   CacheBlockInfo::clone(cache_block_info);
}
