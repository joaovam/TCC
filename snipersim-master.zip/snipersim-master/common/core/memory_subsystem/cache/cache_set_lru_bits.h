#ifndef CACHE_SET_LRU_BITS_H
#define CACHE_SET_LRU_BITS_H

#include "cache_set.h"

class CacheSetLRUBits : public CacheSet
{
   public:
      CacheSetLRUBits(CacheBase::cache_t cache_type,
            UInt32 associativity, UInt32 blocksize);
      virtual ~CacheSetLRUBits();

      virtual UInt32 getReplacementIndex(CacheCntlr *cntlr);
      void updateReplacementIndex(UInt32 accessed_index);

   protected:
      UInt8* m_lru_bits;
      void moveToMRU(UInt32 accessed_index);
};

#endif /* CACHE_SET_LRU_BITS_H */
