#ifndef __PR_L1_CACHE_BLOCK_INFO_H__
#define __PR_L1_CACHE_BLOCK_INFO_H__

#include "cache_state.h"
#include "cache_block_info.h"
#include "simulator.h"
#include "config.hpp"

class PrL1CacheBlockInfo : public CacheBlockInfo
{
	private:
		UInt32 m_cached_loc_bitvec;
		bool m_has_few_sharers;
		float m_threshold;
		UInt8 m_count;

	public:
      PrL1CacheBlockInfo(IntPtr tag = ~0,
            CacheState::cstate_t cstate = CacheState::INVALID):
         CacheBlockInfo(tag, cstate),
         m_threshold(Sim()->getCfg()->getFloat("perf_model/bitrp/threshold"))
      {}

      ~PrL1CacheBlockInfo() {}

      void setCount(UInt8 count);
};
#endif /* __PR_L1_CACHE_BLOCK_INFO_H__ */
