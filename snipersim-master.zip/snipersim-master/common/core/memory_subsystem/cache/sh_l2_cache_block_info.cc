#include "sh_l2_cache_block_info.h"
#include "log.h"

PrevCacheIndex
SharedL2CacheBlockInfo::getCachedLoc()
{
   LOG_ASSERT_ERROR(m_cached_locs.count() == 1, "m_cached_locs.count() == %u", m_cached_locs.count());

   for(PrevCacheIndex idx = 0; idx < m_cached_locs.size(); ++idx)
      if (m_cached_locs.test(idx))
         return idx;
   assert(false);
}

void
SharedL2CacheBlockInfo::setCachedLoc(core_id_t core_id) //PrevCacheIndex idx)
{
   m_cached_locs.set(core_id);
   updateSharersFlag();
}

void
SharedL2CacheBlockInfo::clearCachedLoc(core_id_t core_id) //PrevCacheIndex idx)
{
   m_cached_locs.reset(core_id);
   updateSharersFlag();
}

void
SharedL2CacheBlockInfo::updateSharersFlag() {
   UInt8 threshold = (16 * m_threshold);
   UInt8 count = countSet();
   m_has_few_sharers = (count <= threshold) ? 1 : 0;
}

UInt8
SharedL2CacheBlockInfo::countSet() {
   size_t count=0;
   for(size_t i=0; i<m_cached_locs.size(); i++) {
      if(m_cached_locs.test(i)) {
         count++;
      }
   }
   return count;
}

void
SharedL2CacheBlockInfo::invalidate()
{
   m_cached_locs.reset();
   m_has_few_sharers = 1;
   CacheBlockInfo::invalidate();
}

void
SharedL2CacheBlockInfo::clone(CacheBlockInfo* cache_block_info)
{
   m_cached_locs = ((SharedL2CacheBlockInfo*) cache_block_info)->getCachedLocs();
   CacheBlockInfo::clone(cache_block_info);
}
