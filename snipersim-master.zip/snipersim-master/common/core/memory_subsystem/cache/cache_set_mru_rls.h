#ifndef CACHE_SET_MRU_RLS_H
#define CACHE_SET_MRU_RLS_H

#include "cache_set.h"

class CacheSetMRURLS : public CacheSet
{
   public:
      CacheSetMRURLS(CacheBase::cache_t cache_type,
            UInt32 associativity, UInt32 blocksize);
      ~CacheSetMRURLS();

      UInt32 getReplacementIndex(CacheCntlr *cntlr);
      void updateReplacementIndex(UInt32 accessed_index);

   private:
      UInt8* m_lru_bits;

};

#endif /* CACHE_SET_MRU_RLS_H */
