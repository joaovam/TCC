#ifndef CACHE_SET_BITRP_H
#define CACHE_SET_BITRP_H

#include "cache_set.h"
#include "log.h"

class CacheSetBitRP : public CacheSet
{
   public:
      CacheSetBitRP(CacheBase::cache_t cache_type,
            UInt32 associativity, UInt32 blocksize);
      ~CacheSetBitRP();

      UInt32 getReplacementIndex(CacheCntlr *cntlr);
      void updateReplacementIndex(UInt32 accessed_index);

   private:
      Random m_rand;

      UInt32* m_least_shared_indexes;

};

#endif /* CACHE_SET_BITRP_H */