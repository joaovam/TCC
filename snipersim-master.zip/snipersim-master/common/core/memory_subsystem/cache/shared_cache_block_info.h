#pragma once

#include "cache_state.h"
#include "cache_block_info.h"
#include "mem_component.h"
#include "simulator.h"
#include "config.hpp"

#include <bitset>

typedef std::bitset<16> CacheSharersType;
typedef UInt8 PrevCacheIndex; // Should hold an integer up to MAX_NUM_PREVCACHES

class SharedCacheBlockInfo : public CacheBlockInfo
{
   private:
      CacheSharersType m_cached_locs;
      float m_threshold;

   public:
      SharedCacheBlockInfo(IntPtr tag = ~0,
            CacheState::cstate_t cstate = CacheState::INVALID)
         : CacheBlockInfo(tag, cstate)
         , m_cached_locs()
         , m_threshold(Sim()->getCfg()->getFloat("perf_model/bitrp/threshold"))
      {}

      ~SharedCacheBlockInfo() {}

      PrevCacheIndex getCachedLoc();
      bool hasCachedLoc() { return m_cached_locs.any(); }
      void setCachedLoc(PrevCacheIndex idx);
      void clearCachedLoc(PrevCacheIndex idx);

      CacheSharersType getCachedLocs() { return m_cached_locs; }
      UInt8 countSet();

      void updateSharersFlag();
      void invalidate();
      void clone(CacheBlockInfo* cache_block_info);
};
