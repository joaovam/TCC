#ifndef CACHE_SET_LFU_BITS_H
#define CACHE_SET_LFU_BITS_H

#include "cache_set.h"

class CacheSetLFUBits : public CacheSet
{
   public:
      CacheSetLFUBits(CacheBase::cache_t cache_type,
            UInt32 associativity, UInt32 blocksize);
      virtual ~CacheSetLFUBits();

      virtual UInt32 getReplacementIndex(CacheCntlr *cntlr);
      void updateReplacementIndex(UInt32 accessed_index);

   protected:
      UInt32* m_freq;
};

#endif /* CACHE_SET_LFU_BITS_H */
