#include "cache_set_lfu_M.h"
#include "log.h"
#include "stats.h"

CacheSetLFUM::CacheSetLFUM(
      CacheBase::cache_t cache_type,
      UInt32 associativity, UInt32 blocksize)
   : CacheSet(cache_type, associativity, blocksize)
{
   m_freq = new UInt32[m_associativity];
   for (UInt32 i = 0; i < m_associativity; i++)
      m_freq[i] = 0;
   m_mru_state = CacheState::MODIFIED;
}

CacheSetLFUM::~CacheSetLFUM() {
   delete [] m_freq;
}

UInt32
CacheSetLFUM::getReplacementIndex(CacheCntlr *cntlr)
{
   // First try to find an invalid block
   for (UInt32 i = 0; i < m_associativity; i++)
   {
      if (!m_cache_block_info_array[i]->isValid())
      {
         m_freq[i] = 1;
         return i;
      }
   }

   UInt32 index = 0;
   UInt32 index2 = 0;
   UInt8 min_freq = m_freq[0];
   UInt8 sec_min_freq = m_freq[0];
   for (UInt32 i = 1; i < m_associativity; i++)
   {
      if (m_freq[i] < min_freq && isValidReplacement(i))
      {
         sec_min_freq = min_freq;
         min_freq = m_freq[i];
         index = i;
      } else if (m_freq[i] < sec_min_freq && m_freq[i] != min_freq) {
         sec_min_freq = m_freq[i];
         index2 = i;
      }
   }
   LOG_ASSERT_ERROR(index < m_associativity, "Error Finding LFU");
   LOG_ASSERT_ERROR(index < m_associativity, "Error Finding 2ndLFU");

   if(m_cache_block_info_array[index]->getCState() == m_mru_state) {
      m_freq[index2] = 0;
      return index2;
   } else {
      m_freq[index] = 0;
      return index;
   }      

   return index;
}

void
CacheSetLFUM::updateReplacementIndex(UInt32 accessed_index)
{
   m_freq[accessed_index]++;
}
