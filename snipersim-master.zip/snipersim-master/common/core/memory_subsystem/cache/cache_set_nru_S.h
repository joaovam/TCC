#ifndef CACHE_SET_NRU_S_H
#define CACHE_SET_NRU_S_H

#include "cache_set.h"

class CacheSetNRUS : public CacheSet
{
   public:
      CacheSetNRUS(CacheBase::cache_t cache_type,
            UInt32 associativity, UInt32 blocksize);
      ~CacheSetNRUS();

      UInt32 getReplacementIndex(CacheCntlr *cntlr);
      void updateReplacementIndex(UInt32 accessed_index);

   private:
      UInt8* m_lru_bits;
      UInt8  m_num_bits_set;
      UInt8  m_replacement_pointer;
      CacheState::cstate_t m_mru_state;
};

#endif /* CACHE_SET_NRU_S_H */
