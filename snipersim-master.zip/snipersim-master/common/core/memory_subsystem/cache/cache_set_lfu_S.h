#ifndef CACHE_SET_LFU_S_H
#define CACHE_SET_LFU_S_H

#include "cache_set.h"

class CacheSetLFUS : public CacheSet
{
   public:
      CacheSetLFUS(CacheBase::cache_t cache_type,
            UInt32 associativity, UInt32 blocksize);
      virtual ~CacheSetLFUS();

      virtual UInt32 getReplacementIndex(CacheCntlr *cntlr);
      void updateReplacementIndex(UInt32 accessed_index);

   protected:
      UInt32* m_freq;
      CacheState::cstate_t m_mru_state;
};

#endif /* CACHE_SET_LFU_S_H */
