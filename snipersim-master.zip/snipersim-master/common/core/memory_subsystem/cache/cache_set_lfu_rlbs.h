#ifndef CACHE_SET_LFU_RLBS_H
#define CACHE_SET_LFU_RLBS_H

#include "cache_set.h"

class CacheSetLFURLBS : public CacheSet
{
   public:
      CacheSetLFURLBS(CacheBase::cache_t cache_type,
            UInt32 associativity, UInt32 blocksize);
      virtual ~CacheSetLFURLBS();

      virtual UInt32 getReplacementIndex(CacheCntlr *cntlr);
      void updateReplacementIndex(UInt32 accessed_index);

   protected:
      UInt32* m_freq;
};

#endif /* CACHE_SET_LFU_RLBS_H */
