#include "cache_set_random_E.h"
#include "log.h"

#include <time.h>

// RANDOM: Selects the victim line randomly (from among valid lines)

CacheSetRandomE::CacheSetRandomE(
      CacheBase::cache_t cache_type,
      UInt32 associativity, UInt32 blocksize) :
   CacheSet(cache_type, associativity, blocksize)
{
   m_rand.seed(time(NULL));
   m_mru_state = CacheState::EXCLUSIVE;
}

CacheSetRandomE::~CacheSetRandomE()
{
}

UInt32
CacheSetRandomE::getReplacementIndex(CacheCntlr *cntlr)
{
   UInt32 chances = 0;
   UInt32 index;
   do {
      // Invalidations may mess up the LRU bits
      for (UInt32 i = 0; i < m_associativity; i++)
      {
          if (!m_cache_block_info_array[i]->isValid()) {
            return i;
          }
      }

      index = (m_rand.next() % m_associativity);
      // Tem uma chance de verificar se o estado é MRU
      // Se sim, randomiza denovo, com chance de ser o mesmo.
      if(m_cache_block_info_array[index]->getCState() == m_mru_state && chances<1) {
         chances++;
         index = (m_rand.next() % m_associativity);
      }
   } while (isValidReplacement(index));

   return index;
}

void
CacheSetRandomE::updateReplacementIndex(UInt32 accessed_index)
{
}
