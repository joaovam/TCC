#ifndef CACHE_SET_PLRU_RLBS_H
#define CACHE_SET_PLRU_RLBS_H

#include "cache_set.h"

class CacheSetPLRURLBS : public CacheSet
{
   public:
      CacheSetPLRURLBS(CacheBase::cache_t cache_type,
            UInt32 associativity, UInt32 blocksize);
      ~CacheSetPLRURLBS();

      UInt32 getReplacementIndex(CacheCntlr *cntlr);
      void updateReplacementIndex(UInt32 accessed_index);

   private:
      UInt8 b[16];
};

#endif /* CACHE_SET_PLRU_RLBS_H */
