#ifndef CACHE_SET_LFU_H
#define CACHE_SET_LFU_H

#include "cache_set.h"

class CacheSetLFU : public CacheSet
{
   public:
      CacheSetLFU(CacheBase::cache_t cache_type,
            UInt32 associativity, UInt32 blocksize);
      virtual ~CacheSetLFU();

      virtual UInt32 getReplacementIndex(CacheCntlr *cntlr);
      void updateReplacementIndex(UInt32 accessed_index);

   protected:
      UInt32* m_freq;
};

#endif /* CACHE_SET_LFU_H */
