#ifndef CACHE_SET_PLRU_DMRUS_H
#define CACHE_SET_PLRU_DMRUS_H

#include "cache_set.h"

class CacheSetPLRUDMRUS : public CacheSet
{
   public:
      CacheSetPLRUDMRUS(CacheBase::cache_t cache_type,
            UInt32 associativity, UInt32 blocksize);
      ~CacheSetPLRUDMRUS();

      UInt32 getReplacementIndex(CacheCntlr *cntlr);
      void updateReplacementIndex(UInt32 accessed_index);

   private:
      UInt8 b[16];
      CacheState::cstate_t m_mru_state;
      void updateMRUState(UInt32 accessed_index);
};

#endif /* CACHE_SET_PLRU_H */
